//=============================================================
//							INTRODUCTION
//=============================================================
/*
	1 - Nguyen Duy Duc , Ecole Polytechnique , 18/7/2012
	2 - Advisor: Prof.Denis Grebenkov
	3 - DLA grows on circle , apply hierarchical maps , Whitsney decomposition idea
	4 - run on ubuntu 11.10 
	5 - Use Mother-Of-All in randoma.h instead of srand() to get better uniform distribution
	6 - Run code: (Ubuntu terminal)
		g++ -Wall -c ./2DDLABasic.cpp
		g++ -Wall -g 2DDLABasic.o randomaelf32.a -o 2DDLABasic
		./2DDLABasic
*/
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h> //for rand , srand , clock
#include <math.h>
#include <fstream>
#include <sstream>
#include <string.h>
//#include "randoma.h"
#include "xrand.h"
//needed but no idea why ?
using namespace std;
const float pi = M_PI;
//float MotherRandom(void){ return Xrandom(); }

float dX, dY;


void random2dsurf(float &x0, float &y0, float r0){                  //  Generate random variables on the boundary of the unit sphere
  float angle = 2*pi*Xrandom();
  x0 = r0 * cos(angle);  y0 = r0 * sin(angle);
//  x0 = nrand();  y0 = nrand();  rr0 = r0/sqrt(x0*x0+y0*y0);  
//  x0 *= rr0;     y0 *= rr0;
}


//=============================================================
//							Struct Map
//=============================================================
/*
	1. Control a Square Map by its point Left,Down angle.
	2. Each Map has Level , Flag turn on if it has cluster inside , size L ,
	   4 children M[4] ,Father points to its father map, two pointers point to two map have the same level Next 
	   and Previous , so all the maps have the same level will be linked together.
	3. List point to list of particle inside it.
	4. LevelMapList points to the map which is end of the list of same level maps.
*/
typedef struct Node
{
	float X;
	float Y;
	int Branch;
	Node* Next;
}Node;
typedef struct Map
{
	int Level;
	int Flag; //0 1
	
	float X;
	float Y;
	float L;
	
	Map* M[4];
	
	Map* Next;
	Map* Pre;
	Map* Father;
	
	Node* List;
}Map;
typedef struct LevelMapList
{
	int Level;
	Map* p;
	LevelMapList* Next;
	LevelMapList* Pre;
}LevelMapList;
//=============================================================
//							Node
//=============================================================
void InsertNode(Node* &T,float X,float Y,int Branch)
{
	Node* p = new Node;
	p->X = X;
	p->Y = Y;
	p->Branch = Branch;
	if(T == NULL)
		T = p;
	else
	{
		Node* W = T;
		while(W->Next != NULL)
		{
			W = W->Next;
		}
		W->Next = p;
	}
};
//=============================================================
//							LevelMapList
//=============================================================
void InsertLevelMapList(LevelMapList* &T,int Level,Map* M)
{
	if(T==NULL)
	{
		T = new LevelMapList;
		T->Level = Level;
		T->p = M;
	}
	else
	{
		if(T->Level == Level)
		{
			T->p->Next = M;
			M->Pre = T->p;
			T->p = M;
		}
		if(T->Level > Level)
		{
			InsertLevelMapList(T->Pre,Level,M);
		}
		if(T->Level < Level)
		{
			InsertLevelMapList(T->Next,Level,M);
		}
	}	
};
//=============================================================
//							Map
//=============================================================
void CreateMap(Map* T,int Level)
/*
	1. Create Root Map
	2. size = 2^(Level - 1)
 	3. center of Root Map is the origin (0,0)
*/
{
	if(T == NULL)	
		T = new Map;
	T->Level = Level;
	T->L = 1;
	for(int i=1; i <= Level-1 ;i++)
	{
		T->L = T->L*2;
	}
	for(int i=0;i<=3;i++)
	{
		T->M[i] = NULL;
	}
	T->X = -T->L/2;
	T->Y = -T->L/2;
};
void DeleteMap(Map*T)
{
	for(int i=0;i<=3;i++)
	{
		if(T->M[i])
		{
			DeleteMap(T->M[i]);
		}
	}
	delete T;	
};
void Divide(Map* T,float PosX,float PosY,LevelMapList* LML)
/*
	Creat 4 children of the input Map T
*/
{
	float x = T->X;float y = T->Y;float l = T->L;
	for(int i=0;i<=3;i++)
	{
		if(T->M[i] == NULL)
		{
			T->M[i] = new Map;
			T->M[i]->Level = T->Level - 1;
			T->M[i]->L = l/2;

			T->M[i]->Father = T;
			
			switch(i)
			{
				case 0:
				{
					T->M[i]->X = x;
					T->M[i]->Y = y;
					break;
				}
				case 1:
				{
					T->M[i]->X = x;
					T->M[i]->Y = y + l/2;
					break;
				}
				case 2:
				{
					T->M[i]->X = x + l/2;
					T->M[i]->Y = y + l/2;
					break;
				}
				case 3:
				{
					T->M[i]->X = x + l/2;
					T->M[i]->Y = y;
					break;
				}
			}
			InsertLevelMapList(LML,T->M[i]->Level,T->M[i]);
		}
	}
};
Map* ConstructMapInside(Map* T,float PosX,float PosY,LevelMapList* LML,int Branch)
/*
	continue to devide the Map has PosX,PosY (cluster) until reaches level 1 map
*/
{	
	if(T->Level == 1)
	{
		T->Flag = 1;
		InsertNode(T->List,PosX,PosY,Branch);
		return T;
	}
	else
	{
		float x = T->X;float y = T->Y;float l = T->L;
		T->Flag = 1;
		
		Divide(T,PosX,PosY,LML);

		//Belong to Map 0 OK
		if(x <= PosX && PosX <= x+l/2 && y <= PosY && PosY <= y+l/2)
		{
			return ConstructMapInside(T->M[0],PosX,PosY,LML,Branch);
		}	
		//Belong to Map 1 OK
		if(x <= PosX && PosX <= x+l/2 && y+l/2 <= PosY && PosY <= y+l)
		{
			return ConstructMapInside(T->M[1],PosX,PosY,LML,Branch);
		}
		//Belong to Map 2 OK
		if(x+l/2 <= PosX && PosX <= x+l && y+l/2 <= PosY && PosY <= y+l)
		{
			return ConstructMapInside(T->M[2],PosX,PosY,LML,Branch);
		}
		//Belong to Map 3 OK
		if(x+l/2 <= PosX && PosX <= x+l && y <= PosY && PosY <= y+l/2)
		{
			return ConstructMapInside(T->M[3],PosX,PosY,LML,Branch);
		}
	}
	return NULL;	
};
Map* SetMaps(Map* T,float PosX,float PosY,LevelMapList* LML)
/*
	After devide the Map has (PosX,PosY) (cluster) , modify all the Map ,
	if size of Map < distance from (PosX,PosY) to it then devide this Map
*/
{
		float x = T->X;float y = T->Y;float l = T->L;
		int Flag = 0;// Flag 0->Map T not devide,also its children ; Flag 1->Map T devide,need to check its children
		// Outside T
		// define dis ,Pos belong to region 0 OK
		if(PosX <= x && y <= PosY && PosY <= y+l)
		{
			float dis = x - PosX ;
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 1 OK
		if(PosX <= x && y+l <= PosY)
		{
			float dis = sqrt((x-PosX)*(x-PosX)+(y+l-PosY)*(y+l-PosY));
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 2 OK
		if(x <= PosX && PosX <= x+l && y+l <= PosY)
		{
			float dis = PosY - y -l;
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 3 OK
		if(x+l <= PosX && y+l <= PosY)
		{
			float dis = sqrt((x+l-PosX)*(x+l-PosX)+(y+l-PosY)*(y+l-PosY));
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 4 OK
		if(x+l <= PosX && y <= PosY && PosY <= y+l)
		{
			float dis = PosX - x - l;
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 5 OK
		if(x+l <= PosX && PosY <= y)
		{
			float dis = sqrt((x+l-PosX)*(x+l-PosX)+(y-PosY)*(y-PosY));
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 6 OK
		if(x <= PosX && PosX <= x+l && PosY <= y)
		{
			float dis = y - PosY;
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		// define dis , Pos belong to region 7 OK
		if(PosX <= x && PosY <= y)
		{
			float dis = sqrt((x-PosX)*(x-PosX)+(y-PosY)*(y-PosY));
			if(l >= dis && T->Level >= 2)
			{
				Divide(T,PosX,PosY,LML);
				Flag = 1;
			}
		}
		//Inside T
		if(x <= PosX && PosX <=x+l && y <= PosY && PosY <= y+l)
		{
			Flag =1;
		}
		if(Flag == 1)
		{
			if(T->M[0] && T->Level >= 2)
			SetMaps(T->M[0],PosX,PosY,LML);
			if(T->M[1] && T->Level >= 2)
				SetMaps(T->M[1],PosX,PosY,LML);
			if(T->M[2] && T->Level >= 2)
				SetMaps(T->M[2],PosX,PosY,LML);
			if(T->M[3] && T->Level >= 2)
				SetMaps(T->M[3],PosX,PosY,LML);
		}
	return NULL;
};
Map* FindMap(Map* T,float CurPosX,float CurPosY)
/*
	Find the Map non-devided where (CurPosX,CurPosY) (mobile particle) belong to.
*/
{
	float x = T->X ; float y = T->Y ; float l = T->L;
	//Belong to Map 0 OK+
	if(x <= CurPosX && CurPosX <= x+l/2 && y <= CurPosY && CurPosY <= y+l/2)
	{
		if(T->M[0])
			return FindMap(T->M[0],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	//Belong to Map 1 OK+
	if(x <= CurPosX && CurPosX <= x+l/2 && y+l/2 <= CurPosY && CurPosY <= y+l)
	{
		if(T->M[1])
			return FindMap(T->M[1],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	//Belong to Map 2 OK+
	if(x+l/2 <= CurPosX && CurPosX <= x+l && y+l/2 <= CurPosY && CurPosY <= y+l)
	{
		if(T->M[2])
			return FindMap(T->M[2],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	//Belong to Map 3 OK+
	if(x+l/2 <= CurPosX && CurPosX <= x+l && y <= CurPosY && CurPosY <= y+l/2)
	{
		if(T->M[3])
			return FindMap(T->M[3],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	return NULL;
};
Map* FindMap2(Map* T,float CurPosX,float CurPosY)
/*
	Find the Map level 2 where (CurPosX,CurPosY) (mobile particle) belong to
*/
{
	float x = T->X ; float y = T->Y ; float l = T->L;
	//Belong to Map 0 OK+
	if(x <= CurPosX && CurPosX <= x+l/2 && y <= CurPosY && CurPosY <= y+l/2)
	{
		if(T->M[0] && T->M[0]->Level >= 2)
			return FindMap2(T->M[0],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	//Belong to Map 1 OK+
	if(x <= CurPosX && CurPosX <= x+l/2 && y+l/2 <= CurPosY && CurPosY <= y+l)
	{
		if(T->M[1] && T->M[1]->Level >= 2)
			return FindMap2(T->M[1],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	//Belong to Map 2 OK+
	if(x+l/2 <= CurPosX && CurPosX <= x+l && y+l/2 <= CurPosY && CurPosY <= y+l)
	{
		if(T->M[2] && T->M[2]->Level >= 2)
			return FindMap2(T->M[2],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	//Belong to Map 3 OK+
	if(x+l/2 <= CurPosX && CurPosX <= x+l && y <= CurPosY && CurPosY <= y+l/2)
	{
		if(T->M[3] && T->M[3]->Level >= 2)
			return FindMap2(T->M[3],CurPosX,CurPosY);
		else
		{
			return T;
		}
	}
	return NULL;
};
float NBCheck2(Map* T,float CurPosX,float CurPosY,Map*Root,Map* NB[],Node* &MinPar)
/*
	Find the neighbor of level 2
*/
{
	float x = T->X;float y = T->Y;float l = T->L;
	//Neighbor 0 Ok
	NB[0] = FindMap2(Root,x-l-0.1,y+l/2);
	//Neighbor 1 Ok
	NB[1] = FindMap2(Root,x-l-0.1,y+2*l+0.1);
	//Neighbor 2 Ok
	NB[2] = FindMap2(Root,x+l/2,y+2*l+0.1);
	//Neighbor 3 Ok
	NB[3] = FindMap2(Root,x+2*l+0.1,y+2*l+0.1);
	//Neighbor 4 Ok
	NB[4] = FindMap2(Root,x+2*l+0.1,y+l/2);
	//Neighbor 5 Ok
	NB[5] = FindMap2(Root,x+2*l+0.1,y-l-0.1);
	//Neighbor 6 Ok
	NB[6] = FindMap2(Root,x+l/2,y-l-0.1);
	//Neighbor 7 Ok
	NB[7] = FindMap2(Root,x-l-0.1,y-l-0.1);
	//Father 
	NB[8] = T->Father;

	float d = 10;float r;
	for(int i=0;i<=8;i++)
	{
		for(int j=0;j<=3;j++)
		{
			if(NB[i]->M[j])
			{
				Node *p = NB[i]->M[j]->List;
				if(p && NB[i]->M[j]->Level == 1)
				{
					while(p)
					{
						r = sqrt((CurPosX-p->X)*(CurPosX-p->X)+(CurPosY-p->Y)*(CurPosY-p->Y));
						if(d > r)
						{
							d = r;
							MinPar = p;
						}
						p = p->Next;
					}
				}
			}
		}
	}
	if(d==10)
	{
		return 0.5;
	}
	else if(d > 1)// d<2
	{
		return d-1;
	}
	return 0;
};
void Expand3(Map* &T,LevelMapList* LML,int Flag)
/*
	The Map Root will be a child of a New Map 
*/
{
	float x = T->X;float y = T->Y;float l = T->L;
	Map* Root = new Map;
	Root->Level = T->Level+1;
	Root->Flag = 1;
	Root->L = 2*l;
	T->Father = Root;
	
	Root->M[Flag] = T;
	InsertLevelMapList(LML,Root->Level,Root);

	switch (Flag)
	{
		case 0:
		{
			Root->X = x; 
			Root->Y = y;
			break;
		}
		case 1:
		{
			Root->X = x; 
			Root->Y = y-l;
			break;
		}
		case 2:
		{
			Root->X = x-l; 
			Root->Y = y-l;
			break;
		}
		case 3:
		{
			Root->X = x-l; 
			Root->Y = y;
			break;
		}
	}
	Divide(Root,1,1,LML);
	T = Root;
};
void Hamonic(Map* Root,float Rrelease,int t,int Num)
{
	cout << "Harmonic Starting ...";
	init_random(0,0);

	//int seed = time(0);
	//MotherRandomInit(seed);
	
	Map* NB[9];
	for(int i=0;i<=8;i++)
	{
		NB[i] = NULL;
	}
	Map* CurMap;
	Node* MinPar = NULL;
	
	float STEP;
	float CurPosX ;
	float CurPosY ;

	float HMN[t];
	for(int i=0;i<t;i++ )
	{
		HMN[i] = 0;
	}

	for(int i=1;i <= Num;i++)
	{
		random2dsurf(CurPosX,CurPosY,Rrelease);
		//startangle = 2*pi* MotherRandom();
		//CurPosX = Rrelease*cos(startangle);
		//CurPosY = Rrelease*sin(startangle);
		//Move untill stuck
		while(1)
		{
			// Find Step
			CurMap = FindMap(Root,CurPosX,CurPosY);
			if(CurMap == NULL)
			{
				cout << "CurMap NULL" << endl;
				break;
			}
			if(CurMap->Level == 1)
			{
				STEP = NBCheck2(CurMap,CurPosX,CurPosY,Root,NB,MinPar);
			}
			else
			{
				STEP = CurMap->L-0.5;
			}
			// Jump
			random2dsurf(dX,dY,STEP);		
            CurPosX += dX;  CurPosY += dY;
			//startangle = 2*pi* MotherRandom();
			//CurPosX = CurPosX+ STEP*cos(startangle);
			//CurPosY = CurPosY+ STEP*sin(startangle);
			if(STEP < 0.1)
			{
				HMN[MinPar->Branch-1] ++;
				break;
			}
			//outside Rkill -> start again
			if(CurPosX*CurPosX + CurPosY*CurPosY > 3*Rrelease*3*Rrelease) 
			{
				random2dsurf(CurPosX,CurPosY,Rrelease);
				//startangle = 2*pi* MotherRandom();
				//CurPosX = Rrelease*cos(startangle);
				//CurPosY = Rrelease*sin(startangle);
			}
		}//stuck

		for(int h=0;h<=8;h++)
		{
			NB[h] = NULL;
		}
		MinPar = NULL;
	}
	for(int i=0;i<t;i++)
	{
		HMN[i] = HMN[i]/Num;
	}
	cout << "Complete." << endl;

	ofstream ftPn;
	ftPn.open("tPn.txt");
	FILE * fDLAO;
	char line[100];
	int c = 0;
	fDLAO = fopen("2DDLAO.txt","r");
	fseek(fDLAO,0,SEEK_SET);

	while(!feof(fDLAO) && c<t)//
	{
		fgets(line,100,fDLAO);
		int ii = strlen(line);
		for(int i=0;i<ii-1;i++)
		{
			ftPn << line[i];
		}
		ftPn << " " << HMN[c] << endl;
		c++;
	}

	fclose(fDLAO);
	ftPn.close();

	cout << "Complete print out Harmonic Measure (tPn.txt)" << endl;
};
//=============================================================
//							Main 
//=============================================================
int main(int argc, char **argv)
{
	init_random(0,0);
//	int seed = time(0);
//	MotherRandomInit(seed);

	cout << "------------------------------------" << endl;
	cout << "		2D DLA version" << endl;
	cout << "- Harmonic Measure of Particles at The End" << endl;
	cout << "------------------------------------" << endl;
	string ans;
	int HMNFlag;
	//---------------------------------------------------------------
	int numpoints;	
	int Num;
	
	if (argc > 1)
	{
		sscanf(argv[1], "%d", &numpoints);
	}	
	else 
	{
		cout << "Enter Cluster Size" << endl;
		cin >> numpoints;
	}
	cout << "Cluster Size is " << numpoints << endl;

	if (argc > 2)
	{
		sscanf(argv[2], "%d", &Num);
	}	
	else
	{
		cout << "Enter Number of particles for Harmonic Measure" << endl;
		cin >> Num;		
	}

	if (Num > 0)   
		HMNFlag = 1;
	else
		HMNFlag = 0;

	cout << "Number of particles for Harmonic measure is " << Num << endl;

	int ProStep = numpoints/100;

	cout << "Starting ... " << endl;
	//---------------------------------------------------------------
	float r = 0.5; //radius of particle
	float Rcluster = r;
	float Rrelease = Rcluster+20;
	float Rkill = 3*Rrelease;
	float STEP;
	float x;
	Map* CurMap;
	Node* MinPar = NULL;
	Map* NB[9];
	//float startangle;
	float CurPosX = 0;
	float CurPosY = 0;

	LevelMapList* LML = NULL;
	Map* Root = NULL;
	
	ofstream fDLAO;
	fDLAO.open("2DDLAO.txt");

	//ofstream ftPn;
	//ftPn.open("tPn.txt");
		
	Root = new Map;
	LML = new LevelMapList;
	CreateMap(Root,12);
	InsertLevelMapList(LML,12,Root);
		
	for(int i=0;i<=8;i++)
	{
		NB[i] = NULL;
	}
		
	//=================== 1000 PARTICLES ON CIRCLE =======================
	//random2dsurf

	//Seed
	ConstructMapInside(Root,CurPosX,CurPosY,LML,1);
	SetMaps(Root,CurPosX,CurPosY,LML);

	fDLAO << CurPosX << " " << CurPosY << endl;

	for(int t=1;t <= numpoints;t++)
	{
		random2dsurf(CurPosX,CurPosY,Rrelease);
		//startangle = 2*pi* MotherRandom();
		//CurPosX = Rrelease*cos(startangle);
		//CurPosY = Rrelease*sin(startangle);
		//Move untill stuck
		while(1)
		{
			// Find Step
			CurMap = FindMap(Root,CurPosX,CurPosY);
			if(CurMap == NULL)
			{
				cout << "CurMap NULL" << endl;
				break;
			}
			if(CurMap->Level == 1)
			{
				STEP = NBCheck2(CurMap,CurPosX,CurPosY,Root,NB,MinPar);
			}
			else
			{
				STEP = CurMap->L-0.5;
			}
			// Jump
			random2dsurf(dX,dY,STEP);		
            CurPosX += dX;  CurPosY += dY;

			//startangle = 2*pi* MotherRandom();
			//CurPosX = CurPosX+ STEP*cos(startangle);
			//CurPosY = CurPosY+ STEP*sin(startangle);
			if(STEP < 0.1)
			{
				ConstructMapInside(Root,CurPosX,CurPosY,LML,t+1);
				SetMaps(Root,CurPosX,CurPosY,LML);
				break;
			}
			//outside Rkill -> start again
			if(CurPosX*CurPosX + CurPosY*CurPosY > Rkill*Rkill) 
			{
				random2dsurf(CurPosX,CurPosY,Rrelease);
				//startangle = 2*pi* MotherRandom();
				//CurPosX = Rrelease*cos(startangle);
				//CurPosY = Rrelease*sin(startangle);
			}
		}//stuck

		fDLAO << CurPosX << " " << CurPosY << endl;

		if(t%ProStep == 0)
		{
			cout << "Growing: " << float(t)/numpoints*100 << "% : " << t << " of "<< numpoints <<endl;
		}
		
		// Reset Values      
		x = sqrt(CurPosX*CurPosX+CurPosY*CurPosY)+r;
		if ( Rcluster < x )
		{
			Rcluster = x;
			Rrelease = Rcluster + 20;
			Rkill = 3*Rrelease;
			float side[4];
			side[0] = -Root->X;
			side[1] = Root->Y+Root->L;
			side[2] = Root->X+Root->L;
			side[3] = -Root->Y;
			float min = side[0];
			for(int h=0;h<=3;h++)
			{
				if(side[h] < min)
				{
					min = side[h];
				}
			}
			if(Rkill + 20 > min)
			{		
				Expand3(Root,LML,3);
				Expand3(Root,LML,1);
				Expand3(Root,LML,2);
				Expand3(Root,LML,0);
				cout << "Map Expand" << endl;
			}	
		}
		for(int h=0;h<=8;h++)
		{
			NB[h] = NULL;
		}
		MinPar = NULL;
	}
	fDLAO.close();
	cout << "Complete Print Out DLA in Order "<< endl;		
	//ftPn.close();	

	if(HMNFlag == 1)
	{
		Hamonic(Root,Rrelease,numpoints+1,Num);
	}
	return 0;
};

